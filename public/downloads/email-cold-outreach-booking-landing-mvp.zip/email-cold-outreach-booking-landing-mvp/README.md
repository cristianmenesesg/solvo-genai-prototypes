# Booking landing page — MVP — prototipo

Prototipo de **Solvo Sales Platform** (Solvo GenAI). Design system: `solvo-global`.

## Versiones
- Landing: `landing.html`

## Cómo abrir
Es un sitio HTML estático y self-contained.
- Rápido: abrí `landing.html` en el navegador.
- Recomendado (sobre todo apps/decks con navegación): serví la carpeta y andá a http://localhost:3000
  ```bash
  npx serve .
  ```

> Al agendar, la landing navega a la página de confirmación (mismo flujo).
