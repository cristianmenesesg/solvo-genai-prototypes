# Cold email — prototipo

Prototipo de **Solvo Sales Platform** (Solvo GenAI). Design system: `solvo-global`.

## Versiones
- Overview: `cold-email-preview.html`
- Template (booking inline): `brevo-template.html`
- CTA a landing: `brevo-cold-email-landing-cta.html`

## Cómo abrir
Es un sitio HTML estático y self-contained.
- Rápido: abrí `cold-email-preview.html` en el navegador.
- Recomendado (sobre todo apps/decks con navegación): serví la carpeta y andá a http://localhost:3000
  ```bash
  npx serve .
  ```
