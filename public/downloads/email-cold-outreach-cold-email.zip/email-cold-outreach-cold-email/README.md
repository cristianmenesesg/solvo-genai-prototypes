# Cold email — prototipo

Prototipo de **Solvo Sales Platform** (Solvo GenAI). Design system: `solvo-global`.

## Versiones
- Preview: `brevo-cold-email-landing-cta-preview.html`
- Email (Brevo): `brevo-cold-email-landing-cta.html`

## Cómo abrir
Es un sitio HTML estático y self-contained.
- Rápido: abrí `brevo-cold-email-landing-cta-preview.html` en el navegador.
- Recomendado (sobre todo apps/decks con navegación): serví la carpeta y andá a http://localhost:3000
  ```bash
  npx serve .
  ```
