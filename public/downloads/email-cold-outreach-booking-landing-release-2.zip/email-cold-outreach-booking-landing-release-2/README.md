# Booking landing page — Release 2 — prototipo

Prototipo de **Solvo Sales Platform** (Solvo GenAI). Design system: `solvo-global`.

## Versiones
- Estándar: `landing-v2.html`
- Quickbook: `landing-v2-quickbook.html`

## Cómo abrir
Es un sitio HTML estático y self-contained.
- Rápido: abrí `landing-v2.html` en el navegador.
- Recomendado (sobre todo apps/decks con navegación): serví la carpeta y andá a http://localhost:3000
  ```bash
  npx serve .
  ```
