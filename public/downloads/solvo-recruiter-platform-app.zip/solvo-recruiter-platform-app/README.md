# Recruiter Platform (app) — prototipo

Prototipo de **Solvo Recruiter Platform** (Solvo GenAI). Design system: `solvo-global`.

## Versiones
- App: `index.html`

## Cómo abrir
Es un sitio HTML estático y self-contained.
- Rápido: abrí `index.html` en el navegador.
- Recomendado (sobre todo apps/decks con navegación): serví la carpeta y andá a http://localhost:3000
  ```bash
  npx serve .
  ```

> Arranca en el login; usá el selector de usuario demo para entrar.
