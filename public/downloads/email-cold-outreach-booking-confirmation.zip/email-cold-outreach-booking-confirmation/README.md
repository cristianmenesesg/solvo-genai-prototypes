# Booking confirmation (email) — prototipo

Prototipo de **Solvo Sales Platform** (Solvo GenAI). Design system: `solvo-global`.

## Versiones
- Preview: `brevo-booking-confirmation-preview.html`
- Prospecto: `brevo-booking-confirmation-prospect.html`
- Cuenta (interno): `brevo-booking-confirmation-account.html`

## Cómo abrir
Es un sitio HTML estático y self-contained.
- Rápido: abrí `brevo-booking-confirmation-preview.html` en el navegador.
- Recomendado (sobre todo apps/decks con navegación): serví la carpeta y andá a http://localhost:3000
  ```bash
  npx serve .
  ```
