# Landing de agendamiento — prototipo

Prototipo de **Solvo Sales Platform** (Solvo GenAI). Design system: `solvo-global`.

## Versiones
- Release 1: `landing.html`
- Release 2 · estándar: `landing-v2.html`
- Release 2 · quickbook: `landing-v2-quickbook.html`

## Cómo abrir
Es un sitio HTML estático y self-contained.
- Rápido: abrí `landing.html` en el navegador.
- Recomendado (sobre todo apps/decks con navegación): serví la carpeta y andá a http://localhost:3000
  ```bash
  npx serve .
  ```
